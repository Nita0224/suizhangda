import {copyFile, mkdir, readFile, writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

const here = path.dirname(fileURLToPath(import.meta.url));
const desktop = path.resolve(here, '..');
const source = path.resolve(desktop, '..');
const web = path.join(desktop, 'web');
await mkdir(web, {recursive: true});

const assets = [
  'business.js', 'policy.js', 'manifest.webmanifest',
  'icon.svg', 'icon-192.png', 'icon-512.png'
];
for (const file of assets) {
  await copyFile(path.join(source, file), path.join(web, file));
}
await copyFile(path.join(source, 'icon-512.png'), path.join(desktop, 'icon-512.png'));

let html = await readFile(path.join(source, 'app.html'), 'utf8');
html = html.replace(
  /<script>if\("serviceWorker" in navigator\)\{navigator\.serviceWorker\.register\("\.\/sw\.js"\)\.catch\(function\(\)\{\}\)\}<\/script>/,
  ''
);
html = html.replaceAll('这台手机', '这台电脑')
  .replaceAll('换手机', '换电脑')
  .replaceAll('新手机', '新电脑');
await writeFile(path.join(web, 'app.html'), html, 'utf8');
console.log('已复制当前穗账达网页到桌面版安装源文件。');
