'use strict';

const {app, BrowserWindow, dialog, protocol, net, shell} = require('electron');
const {autoUpdater} = require('electron-updater');
const path = require('node:path');
const {pathToFileURL} = require('node:url');

const SCHEME = 'suizhangda';
const HOST = 'app';
const WEB_ROOT = path.join(__dirname, 'web');
const ALLOWED_FILES = new Set([
  'app.html', 'business.js', 'policy.js', 'manifest.webmanifest',
  'icon.svg', 'icon-192.png', 'icon-512.png'
]);

function startUpdateChecks(win) {
  if (!app.isPackaged || process.platform !== 'win32') return;
  autoUpdater.autoDownload = true;
  autoUpdater.autoInstallOnAppQuit = true;
  autoUpdater.allowPrerelease = false;
  autoUpdater.on('error', error => {
    console.error('更新检查失败：', error);
  });
  autoUpdater.on('update-downloaded', async info => {
    if (win.isDestroyed()) return;
    const choice = await dialog.showMessageBox(win, {
      type: 'info',
      title: '穗账达更新已就绪',
      message: `新版本 ${info.version} 已下载完成`,
      detail: '现在重启即可使用更新，已保存的本机账本会保留。',
      buttons: ['现在重启更新', '稍后'],
      defaultId: 0,
      cancelId: 1,
      noLink: true
    });
    if (choice.response === 0) autoUpdater.quitAndInstall(false, true);
  });
  const check = () => autoUpdater.checkForUpdates().catch(error => {
    console.error('无法检查更新：', error);
  });
  setTimeout(check, 5000);
  setInterval(check, 6 * 60 * 60 * 1000);
}

protocol.registerSchemesAsPrivileged([{
  scheme: SCHEME,
  privileges: {standard: true, secure: true, supportFetchAPI: true}
}]);

app.setAppUserModelId('cn.suizhangda.desktop');

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    const win = BrowserWindow.getAllWindows()[0];
    if (win) {
      if (win.isMinimized()) win.restore();
      win.focus();
    }
  });

  app.whenReady().then(() => {
    protocol.handle(SCHEME, request => {
      const url = new URL(request.url);
      const file = decodeURIComponent(url.pathname).replace(/^\//, '');
      if (url.hostname !== HOST || !ALLOWED_FILES.has(file)) {
        return new Response('Not found', {status: 404});
      }
      return net.fetch(pathToFileURL(path.join(WEB_ROOT, file)).toString());
    });

    const win = new BrowserWindow({
      title: '穗账达',
      width: 510,
      height: 860,
      minWidth: 390,
      minHeight: 600,
      backgroundColor: '#F4F7F6',
      autoHideMenuBar: true,
      icon: path.join(__dirname, 'icon-512.png'),
      webPreferences: {
        nodeIntegration: false,
        contextIsolation: true,
        sandbox: true,
        webSecurity: true
      }
    });

    win.webContents.setWindowOpenHandler(({url}) => {
      if (/^https:\/\//i.test(url)) shell.openExternal(url);
      return {action: 'deny'};
    });
    win.webContents.on('will-navigate', (event, url) => {
      if (!url.startsWith(`${SCHEME}://${HOST}/`)) {
        event.preventDefault();
        if (/^https:\/\//i.test(url)) shell.openExternal(url);
      }
    });
    win.loadURL(`${SCHEME}://${HOST}/app.html`);
    startUpdateChecks(win);
  });

  app.on('window-all-closed', () => app.quit());
}
